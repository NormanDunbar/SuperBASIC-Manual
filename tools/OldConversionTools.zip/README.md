# SuperBASIC-Manual - Tools
RWAP Software's Online SuperBASIC manual - for conversion purposes

This directory is filled with tools and goodies that I used or wrote when
converting the old HTML into something resembling ReStructuredText. Much of what you see here is only used when the RST files need fixing up or something like that anyway!

Don't go looking for first class codeing here by the way, there isn't any!

